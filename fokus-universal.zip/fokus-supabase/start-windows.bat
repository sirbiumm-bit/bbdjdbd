@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js не найден.
  echo Установи LTS-версию с https://nodejs.org/ и снова запусти этот файл.
  echo После установки закрой и заново открой окно, если оно было открыто.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Устанавливаю зависимости проекта...
  call npm install
  if errorlevel 1 (echo Не удалось установить зависимости. Проверь интернет и повтори запуск. & pause & exit /b 1)
)
echo Запускаю Фокус. Для открытия на этом компьютере используй http://localhost:5173
echo Для открытия с телефона в той же Wi-Fi-сети используй локальный IP компьютера и порт 5173.
call npm run dev -- --host 0.0.0.0
pause
