#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Нужен Node.js LTS: https://nodejs.org/"
  exit 1
fi
if [ ! -d node_modules ]; then
  npm install
fi
echo "Фокус запускается: http://localhost:5173"
echo "Для устройств в той же Wi-Fi-сети открой IP этого компьютера и порт 5173."
npm run dev -- --host 0.0.0.0
